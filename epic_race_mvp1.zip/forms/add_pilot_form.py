from flask_wtf import FlaskForm
from wtforms import StringField, FileField, SubmitField
from wtforms.validators import DataRequired


class AddPilotForm(FlaskForm):
    name = StringField('Имя Фамилия', validators=[DataRequired()])
    photo = FileField('Выберите фотографию', validators=[DataRequired()])
    submit = SubmitField('Добавить')