import sqlalchemy
from data.db_session import SqlAlchemyBase
from sqlalchemy import orm
from flask_login import UserMixin


class Pilot(SqlAlchemyBase, UserMixin):
    __tablename__ = 'pilot'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    name = sqlalchemy.Column(sqlalchemy.String)
    photo = sqlalchemy.Column(sqlalchemy.LargeBinary)
